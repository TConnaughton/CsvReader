import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.stream.Collectors;

public class CsvReader
{
    private static final String COMMA = ",";
    private static final String COMMA_SPACE = ", ";

    public static void main(final String[] args)
    {
        ArrayList<Enrollee> enrollees = new ArrayList<>();
        ArrayList<ArrayList<Enrollee>> enrolleesByCompany = new ArrayList<>();

        try
        {
            //Read from the enrollmentFile.csv file
            enrollees = parseCsvToArray("src/enrollmentFile.csv");
        }
        catch(Exception e)
        {
            System.out.println("There was a general exception while parsing the CSV.");
        }

        enrollees = sortEnrollees(enrollees);

        enrolleesByCompany = separateByCompany(enrollees);

        writeCompaniesToFile(enrolleesByCompany);
    }

    /**
     * This method parses the CSV file to an ArrayList of Enrollee objects
     * @return ArrayList of Enrollees
     * @throws Exception
     */
    private static ArrayList<Enrollee> parseCsvToArray(final String fileName) throws Exception
    {
        ArrayList<Enrollee> enrollees = new ArrayList<>();

        //Create a file reader from the CSV
        try (BufferedReader br = new BufferedReader(new FileReader(fileName)))
        {
            String line;
            int lineNo = 1;
            int successfulRecords = 0;

            //Read in each line from the reader
            while ((line = br.readLine()) != null)
            {
                //Split the lines on commas
                final String[] values = line.split(COMMA);

                //If there are 4 values, proceed. Otherwise, print error message to console.
                if(values.length == 4)
                {
                    enrollees.add(new Enrollee(values, lineNo));
                    successfulRecords++;
                }
                else
                {
                    System.out.println("Not enough entries when parsing Line Number" + lineNo);
                }

                //Keep track of the line number for logging purposes
                lineNo++;
            }

            //Print out the number of records that were processed
            System.out.println(successfulRecords + " records processed.");
        }

        return enrollees;
    }

    /**
     * This method sorts a list of Enrollees, first by Company, then by Last Name, then by First Name
     * @param unsortedList
     * @return Sorted ArrayList of Enrollees
     */
    private static ArrayList<Enrollee> sortEnrollees(final ArrayList<Enrollee> unsortedList)
    {
        ArrayList<Enrollee> sortedList = new ArrayList<>();

        if(unsortedList != null && !unsortedList.isEmpty())
        {
            //Sort the unsorted list by company, then last name, then first name
            sortedList = (ArrayList<Enrollee>) unsortedList.stream().sorted(Comparator.comparing(Enrollee::getCompany).thenComparing(Enrollee::getLastName).thenComparing(Enrollee::getFirstName)).collect(Collectors.toList());
        }

        return sortedList;
    }

    /**
     * This method takes a sorted list of Enrollees, and filters them into separate Lists based on company.
     * If there is a dupe user ID in a given company, only the record with the latest version number will be kept.
     * @param sortedList
     * @return A list of companies and their enrollees
     */
    private static ArrayList<ArrayList<Enrollee>> separateByCompany(final ArrayList<Enrollee> sortedList)
    {
        ArrayList<ArrayList<Enrollee>> seperatedLists = new ArrayList<>();

        if(sortedList != null && !sortedList.isEmpty())
        {
            int i = 1;
            int dupeCount = 0;
            String currentCompany = sortedList.get(0).getCompany();
            ArrayList<Enrollee> companyEnrollees = new ArrayList<>();
            HashMap<String, String> userIdAndVersion = new HashMap<>();

            for(Enrollee enrollee: sortedList)
            {
                //If we've moved on to a different company or if the sorted list has ended
                if(!enrollee.getCompany().equalsIgnoreCase(currentCompany))
                {
                    //Add the last company's enrollees, and reset the collections. Then set the current company.
                    seperatedLists.add(companyEnrollees);
                    companyEnrollees = new ArrayList<>();
                    userIdAndVersion = new HashMap<>();
                    currentCompany = enrollee.getCompany();
                }

                //if the user id is a duplicate for that company, then take the latest version
                if(userIdAndVersion.keySet().contains(enrollee.getUserId().toUpperCase()))
                {
                    //If incoming version is later than the one already present in the list
                    if(enrollee.getVersion() > Integer.parseInt(userIdAndVersion.get(enrollee.getUserId().toUpperCase())))
                    {
                        //Remove the old entry in the list
                        for(Enrollee companyEnrollee: companyEnrollees)
                        {
                            if(companyEnrollee.getUserId().toUpperCase().equals(enrollee.getUserId().toUpperCase()))
                            {
                                companyEnrollees.remove(companyEnrollee);
                                break;
                            }
                        }

                        //Update the HashMap with the latest version and add the record with the later version to the company's list
                        userIdAndVersion.put(enrollee.getUserId().toUpperCase(), Integer.toString(enrollee.getVersion()));
                        companyEnrollees.add(enrollee);
                    }

                    dupeCount++;
                }
                else
                {
                    //Add to the HashMap and add the enrollee to the company's list
                    userIdAndVersion.put(enrollee.getUserId().toUpperCase(), Integer.toString(enrollee.getVersion()));
                    companyEnrollees.add(enrollee);
                }

                //If we're at the end of the list, add the last company to the separated lists
                if(sortedList.size() == i++)
                {
                    seperatedLists.add(companyEnrollees);
                }
            }

            System.out.println(dupeCount + " earlier versioned duplicates found and ignored.");
        }



        return seperatedLists;
    }

    /**
     * This method writes each company's list of enrollees to a local CSV file, named output.csv
     * @param enrolleesByCompany
     */
    private static void writeCompaniesToFile(ArrayList<ArrayList<Enrollee>> enrolleesByCompany)
    {
        try
        {
            FileWriter fw = new FileWriter("output.csv");

            for(ArrayList<Enrollee> companyEnrollees: enrolleesByCompany)
            {
                //Writes a line in the file for each enrollee, formatted:
                //User ID, First and Last Name, Version, Company
                for(Enrollee enrollee: companyEnrollees)
                {
                    fw.write(enrollee.getUserId() + COMMA_SPACE + enrollee.getName() + COMMA_SPACE + enrollee.getVersion() + COMMA_SPACE + enrollee.getCompany() + "\n");
                }

                //Add a space between companies
                fw.write("\n");
            }

            fw.close();
        }
        catch(IOException e)
        {
            System.out.println("There was an issue creating the output file.");
        }
    }
}