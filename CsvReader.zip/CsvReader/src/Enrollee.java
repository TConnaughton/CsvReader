public class Enrollee
{
    private String userId = "", name = "", firstName = "", lastName = "", company = "";
    private int version;

    public Enrollee()
    {
    }

    public Enrollee(String[] csvRecord, int lineNo)
    {
        if(csvRecord != null && csvRecord.length == 4)
        {
            userId = csvRecord[0].trim();
            name = csvRecord[1].trim();

            if(name.contains(" "))
            {
                firstName = name.split(" ")[0];
                lastName = name.split(" ")[1];
            }
            else
            {
                System.out.println("There was an issue parsing the first and last name for Line Number " + lineNo);
            }

            try
            {
                version = Integer.parseInt(csvRecord[2].trim());
            }
            catch (Exception e)
            {
                System.out.println("There was an issue parsing the version number for Line Number " + lineNo);
                version = 0;
            }

            company = csvRecord[3].trim();
        }
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getCompany()
    {
        return company;
    }

    public void setCompany(String company)
    {
        this.company = company;
    }

    public int getVersion()
    {
        return version;
    }

    public void setVersion(int version)
    {
        this.version = version;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
}
